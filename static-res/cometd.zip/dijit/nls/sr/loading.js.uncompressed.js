define("dijit/nls/sr/loading", {      
//begin v1.x content
	loadingState: "Učitavanje...",
	errorState: "Nažalost, došlo je do greške"
//end v1.x content
});

