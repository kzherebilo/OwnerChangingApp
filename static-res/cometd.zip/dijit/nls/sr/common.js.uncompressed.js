define("dijit/nls/sr/common", {      
//begin v1.x content
	buttonOk: "U redu",
	buttonCancel: "Otkaži",
	buttonSave: "Sačuvaj",
	itemClose: "Zatvori"
//end v1.x content
});

